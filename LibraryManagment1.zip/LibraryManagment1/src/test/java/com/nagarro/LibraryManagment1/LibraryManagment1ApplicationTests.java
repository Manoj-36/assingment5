package com.nagarro.LibraryManagment1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryManagment1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
