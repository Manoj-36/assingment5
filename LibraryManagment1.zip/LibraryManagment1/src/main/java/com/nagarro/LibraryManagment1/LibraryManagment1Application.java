package com.nagarro.LibraryManagment1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryManagment1Application {

	public static void main(String[] args) {
		SpringApplication.run(LibraryManagment1Application.class, args);
		
		System.out.println("Application running successfully");
	}

}
